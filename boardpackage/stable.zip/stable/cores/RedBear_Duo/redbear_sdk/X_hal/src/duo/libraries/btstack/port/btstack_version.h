


#ifndef __BTSTACK_VERSION_H
#define __BTSTACK_VERSION_H_


#define BTSTACK_MAJOR  0
#define BTSTACK_MINOR  0


#endif
